package javafiles;

public class LangClass {

}
