package javafiles;

import java.sql.Connection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

import database.HiberUtility;
import database.JdbcUtility;
import database.UserEntity;

public class HiberOperations 
{
	Session session=HiberUtility.getSession();
	public boolean checkuser(String uname)
	{
		
		
		try
		{
			session=HiberUtility.getSession();
			String hql = "FROM UserEntity where uname = :username";
			Query query = session.createQuery(hql);
			query.setParameter("username",uname);
			@SuppressWarnings("unchecked")
			List<UserEntity> results = query.list();
			Iterator<UserEntity> it=results.iterator();
			if (it.hasNext()) {
			return true;
			}
			else
			{
			return false;
			}
		}catch(Exception e){}
		return false;
			
		
		
	}
	
	public boolean checkUserAndPassword(String uname,String password){
		
		session=HiberUtility.getSession();
		String sql="FROM UserEntity where uname=:username AND upass=:password";
		Query query=session.createQuery(sql);
		query.setParameter("username",uname);
		query.setParameter("password",password);
		
		
		@SuppressWarnings("unchecked")
		List<UserEntity> results = query.list();
		
		Iterator<UserEntity> it=results.iterator();	
		
		if (it.hasNext()) {
			
			return true;
		}
		else
		{
			
		return false;
		}	
	}
	
	
	
	public boolean checkstatus(String uname)
	{
		
		try
		{
			session=HiberUtility.getSession();
			String hql = "FROM UserEntity where uname = :username";
			Query query = session.createQuery(hql);
			query.setParameter("username",uname);
			@SuppressWarnings("unchecked")
			List<UserEntity> results = query.list();
			Iterator<UserEntity> it=results.iterator();
			UserEntity un=it.next();
			if(un.getStatus()==1)
			{
				return false;
			}
			else
			{
				return true;
			}
			
			
			
		}catch(Exception e)
		{
			System.out.println("error:"+e);
		}
		
		
		
		return false;
	}
	
	
	
	public boolean changestatus(String uname,int status)
	{
	
			session=HiberUtility.getSession();
			String hql = "Update UserEntity set status=:statusval where uname = :username";
			Query query = session.createQuery(hql);
			
			System.out.println(status);
		
			query.setParameter("statusval",status);
			query.setParameter("username",uname);
			
		
			if(query.executeUpdate()==1)
			{
				System.out.println(uname);
				System.out.println(status);
				HiberUtility.closeSession(null);
				return true;
				
			}
			else
			{
				return false;

		}
	

	
	}
	
	
	public void registerUser(int uid,String uname,String upass,int status){
	
			
			Session session=HiberUtility.getSession();
			
			UserEntity obj=new UserEntity();
			obj.setUid(uid);
			obj.setUname(uname);
			obj.setUpass(upass);
			obj.setStatus(status);
			
			
			try
			{
			session.save(obj);
			
			HiberUtility.closeSession(null);
			}catch(Exception e)
			{
				HiberUtility.closeSession(null);
			}
	
	}
		
		
		
	
	
	
	

	
	
	
}
