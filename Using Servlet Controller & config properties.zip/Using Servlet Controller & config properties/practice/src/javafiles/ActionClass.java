package javafiles;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public abstract class ActionClass {

	public abstract String execute(HttpServletRequest request,HttpServletResponse response);
	
}
