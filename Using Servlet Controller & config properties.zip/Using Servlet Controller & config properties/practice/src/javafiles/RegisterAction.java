package javafiles;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;

import database.HiberUtility;
import database.JdbcUtility;

public class RegisterAction extends ActionClass {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) 
	{
		Session session=HiberUtility.getSession();
		int id=Integer.parseInt(request.getParameter("uid"));
		String username=request.getParameter("uname");
		String password=request.getParameter("upass");
		int status=Integer.parseInt(request.getParameter("status"));
		System.out.println("in register");
	
		HiberOperations hb=new HiberOperations();
		try
		{
				if(hb.checkuser(username))
				{
					System.out.println("user alreday exists");
					return "user.exists";
				}
				else
				{
				System.out.println("new users added");
				hb.registerUser(id,username, password, 0);
				return "register.success";
				}
	
			
		}catch(Exception e)
			{System.out.println("error:"+e);}
		return null;
		}
}