package database;




import java.sql.*;
import java.util.Properties;



public class JdbcUtility {
	static Properties prop;
	static Connection con=null;
	
	
	static
	{
			try
			{		
//				prop=new Properties();
//				prop.load(new FileInputStream(filepath));
				Class.forName("com.mysql.jdbc.Driver");
				System.out.println("Loaded Driver");
				
				
			}
			catch(Exception e){
			System.out.println(e);	
			}
		}	
		private static final ThreadLocal<Connection> tlocal=new ThreadLocal<Connection>();
		public static Connection getConnection()
		{
			try
			{
				
				con=tlocal.get();
				if(con==null)
				{
//					con=DriverManager.getConnection(prop.getProperty("url"),
//							prop.getProperty("username"),
//							prop.getProperty("password"));
					con=DriverManager.getConnection("jdbc:mysql://localhost/hello16","root","root");
					tlocal.set(con);
					con.setAutoCommit(false);
					return con;
				}
				else
				{
					return con;
				}
			}catch(Exception e)
			{
				e.printStackTrace();
				return null;
			}
		}
		public static void closeConnection(Exception e) 
		{
			Connection con=tlocal.get();
			if(con!=null)
			{
				try
				{
					if(e==null)
					{
						con.commit();
					}
					else
					{
						con.rollback();
					}
				tlocal.remove();
				con.close();
			}
			catch(Exception e1)
			{
				System.out.println(e1);
			}
			
		}	
	}
	
}


