package example;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import javafiles.HiberOperations;


public class MySessionListener implements HttpSessionListener 
{

    
    public void sessionCreated(HttpSessionEvent event)  
    { 
        HttpSession session=event.getSession();
        System.out.println("session created........"+session.isNew());
        
    }


    public void sessionDestroyed(HttpSessionEvent event)  
    { 
    	
    	HttpSession session=event.getSession();
    	Object ob=session.getAttribute("username");
    	HiberOperations hb=new HiberOperations();
    	hb.changestatus(ob.toString(),0);
    	
    	  System.out.println("session destroyed......");
    }
	
}
