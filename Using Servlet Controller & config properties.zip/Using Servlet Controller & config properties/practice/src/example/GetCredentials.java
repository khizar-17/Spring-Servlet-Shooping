package example;

import java.io.IOException;
import java.util.ResourceBundle;

import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.TagSupport;

import com.sun.org.apache.xerces.internal.util.HTTPInputSource;



public class GetCredentials extends TagSupport{
	
	private String key;
	
	@Override
	public int doEndTag() throws JspException {
	
		JspWriter out=pageContext.getOut();
		HttpSession session=pageContext.getSession();

		ResourceBundle rb=(ResourceBundle) session.getAttribute("rb");
		try{
		out.println(rb.getString(key));
		
		}
		catch(Exception e){}
		return super.doEndTag();
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}
}
